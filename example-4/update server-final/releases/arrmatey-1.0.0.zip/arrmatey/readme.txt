=== ARR Matey! ===
Contributors: neutrinoinc
Donate link: https://www.gofundme.com/save-our-mom-acrocats-cancer-fund
Tags: pirate, talk like a pirate day, tlapd, itlapd, arr, avast, ridiculous, stupid, wcoc
Requires at least: 4.0.1
Tested up to: 4.9.6
Requires PHP: 5.3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make your website piratical by converting the letter R into a more seaworthy RRRRRRR, amongst other similarrrr changes.

== Description ==

Is your website for land-lubbers only and craves the salty adventure of a scurvy pirate?  This plugin will convert the
text on your site to be more piratical.  A sample "r" will become an "rrrrrr", and the like.  It's "off the hook"!

Created in conjunction with [piratejokes.net](https://www.piratejokes.net).

== Installation ==

1. Upload the entire `arrmatey` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Enjoy ye a mug o' grog!

== Frequently Asked Questions ==

= Is this really all the plugin does? =

AYE, that be correct!

= What does a pirate do when he's too wasted to get back to his ship? =

Use his AYE-Phone to call an UBARRRRRR!!!

== Screenshots ==

1. Example of text change after plugin activation - notice the extra Rs, matey!

== Changelog ==

= 1.0.0 =
* This plugin surfaced from the depths of Neptune's domain
