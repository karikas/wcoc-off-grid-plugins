<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} ?>
<tr class="plugin-update-tr active installer-plugin-update-tr">
	<td colspan="3" class="plugin-update colspanchange">
		<div class="notice inline notice-warning notice-alt">
			<?php echo $form; ?><?php // @codingStandardsIgnoreLine ?>
		</div>
	</td>
</tr>
